# My lab log

Two or three lines per milestone: what you tried, what you learned, and which hints you took. Nobody marks this. It is for you,
and for the moment a colleague asks "how did you get that working?".

Three questions that make it useful:
- What surprised me?
- What did Claude get wrong, and how did I notice?
- Could I explain this fix to someone else in one sentence?

---

## Milestone 1: Reproduce the hallucination
- Tried:
- Learned:
- Hints taken:

## Milestone 2: Chunk the plan sheet
- Tried:
- Learned:
- Hints taken:

## Milestone 3: Build the ingestion pipeline
- Tried:
- Learned:
- Hints taken:

## Milestone 4: Write and test retrieval
- Tried:
- Learned:
- Hints taken:

## Milestone 5: Write the grounded prompt
- Tried:
- Learned:
- Hints taken:

## Milestone 6: Re-run the original bug
- Tried:
- Learned:
- Hints taken:

## Milestone 7: Add fixture tests
- Tried:
- Learned:
- Hints taken:

## Milestone 8: Add a staleness check
- Tried:
- Learned:
- Hints taken:

## Homework, milestone 9: A second document type
- Tried:
- Learned:
